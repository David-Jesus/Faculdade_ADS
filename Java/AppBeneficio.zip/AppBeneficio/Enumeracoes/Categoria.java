package AppBeneficio.Enumeracoes;

public enum Categoria {
	EMPREGADO("1 - ",  "Empregado"),
	EMPREGADOR("2 - ", "Empregador"),
	DESEMPREGADO("3 - ", "Desempregado");
	
	private String valor;
	private String descricao;

	private Categoria(String valor, String descricao) {
		this.valor = valor;
		this.descricao = descricao;
	}
	
	public String getValor() {
		return this.valor;
	}
	
	public String getDescricao() {
		return this.descricao;
	}

}
