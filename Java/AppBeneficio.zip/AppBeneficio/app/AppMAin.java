package AppBeneficio.app;

import AppBeneficio.modelagem.EndradaDados;

public class AppMAin {

	public static void main(String[] args) {
		EndradaDados entrada = new EndradaDados();
		entrada.recebeDados();
	}

}
