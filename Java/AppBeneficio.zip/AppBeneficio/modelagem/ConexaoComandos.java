package AppBeneficio.modelagem;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ConexaoComandos {
	public void cadastrar(String nomeCompleto, int idade, String categoria, String uf, double valorBeneficio, String dt_final_recebimento, int qtdFuncionarios, String ehAposentado, int mesesDesempregado) {
		Connection conn = new ConectionFactory().getConnection();
		
		String create = "CREATE TABLE IF NOT EXISTS BENEFICIARIO ("
				+ "id serial not null,"
				+ "nome varchar(40) not null,"
				+ "idade int not null,"
				+ "categoria varchar(40) not null,"
				+ "uf varchar(30) not null,"
				+ "valor_beneficio double precision not null,"
				+ "qtd_funcionarios varchar(3) not null,"
				+ "aposentado varchar(3) not null,"
				+ "dt_final_recebimento date not null,"
				+ "meses_desempregado int not null);";
		 
		
		try {
			Statement statement = conn.createStatement();
			statement.execute(create);		
			
			//String i = "INSERT INTO BENEFICIARIO (nome, idade) values ('"+ nomeCompleto +"', '"+ idade +"', )";
			String insert = "INSERT INTO BENEFICIARIO (nome, idade, categoria, uf, valor_beneficio, dt_final_recebimento, qtd_funcionarios, aposentado, meses_desempregado)  values ('"+ nomeCompleto +"', '" + idade +"',  '"+ categoria +"',  '"+ uf +"',  '"+ valorBeneficio +"', '"+ dt_final_recebimento +"',  '"+ qtdFuncionarios +"',  '"+ ehAposentado +"',  '"+ mesesDesempregado +"')";			
			statement.execute(insert);
			
			System.out.println("Cadastrado com sucesso!");
		} catch (SQLException e) {
			System.out.println("Deu ruim" + e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void listar() {
		try {
			Connection conn = new ConectionFactory().getConnection();
			Statement statement = conn.createStatement();
			
			String select = "SELECT nome, idade, categoria, uf, valor_beneficio, qtd_funcionarios, aposentado, pagamento, dt_final_recebimento, meses_desempregado from BENEFICIARIO order by id ASC";
			
			ResultSet resultSet = statement.executeQuery(select);
			
			//vai mover o resultado para a pr�xima linha
			while(resultSet.next()) {
				System.out.println("Id:" + resultSet.getInt("id"));
				System.out.println("Nome: " + resultSet.getString("nome"));
				System.out.println("Idade: " + resultSet.getInt("idade"));
				System.out.println("Categoria: " + resultSet.getString("categoria"));
				System.out.println("Estado: " + resultSet.getString("uf"));
				System.out.println("Valor do Beneficio: " + resultSet.getDouble("valor_beneficio"));
				System.out.println("Quantidade Funcionarios: " + resultSet.getInt("qtd_funcionarios"));
				System.out.println("Aposentado: " + resultSet.getString("aposentado"));
				System.out.println("Pagamento: " + resultSet.getString("pagamento"));
				System.out.println("Data Final do Recebimento: " + resultSet.getString("dt_final_recebimento"));
				System.out.println("Meses Desempregado: " + resultSet.getInt("meses_desempregado"));
			}	
			
		} catch (SQLException e) {
			System.out.println("Deu ruim" + e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void delete(int id) {
		Connection conn = new ConectionFactory().getConnection();
		
		try {
			Statement statement = conn.createStatement();
			String delete = "delete from BENEFICIARIO where id = "+ id +" ;" ;
			statement.execute(delete);
			
		} catch (SQLException e) {
			System.out.println("Deu ruim" + e.getMessage());
			e.printStackTrace();
		}
		
	}
		
}
