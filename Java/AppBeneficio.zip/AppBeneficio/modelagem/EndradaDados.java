package AppBeneficio.modelagem;

import java.util.Scanner;

import AppBeneficio.Enumeracoes.Categoria;
import AppBeneficio.Enumeracoes.EstadosEnum;

public class EndradaDados {
	Scanner leia = new Scanner(System.in);
	Pessoa pessoa = new Pessoa();

	String opcao = "0";
	boolean verificador = false;

	public void recebeDados() {

		while (opcao == "0") {

			System.out.println("\nEscolha Uma das Op��es: ");
			System.out.println("\t1 - Realizar cadastro;");
			System.out.println("\t2 - Consultar Dados do cadastro;");
			System.out.println("\t3 - Exluir um benefici�rio.");
			System.out.println("\t4 - Fechar o programa.");
			System.out.print("Digite sua escolha: ");
			opcao = leia.next();

			switch (opcao) {

			case "1":

				do {
					System.out.println("\nPor favor digite seu nome completo: ");
					leia.nextLine();
					pessoa.setNome(leia.next());
				} while (pessoa.getNome().length() <= 3);

				do {
					System.out.println("\nPor favor digite sua idade: ");
					leia.nextLine();
					String idade = leia.nextLine();

					try {
						if (Integer.parseInt(idade) > 18) {
							pessoa.setIdade(Integer.parseInt(idade));
							verificador = true;
						} else {

							System.out.println("Desculpe o benef�cio � apenas para maiores de idade!");
						}
					} catch (NumberFormatException e) {
						System.out.println("Digite apenas n�meros!");
					}

				} while (verificador == false);

				System.out.println("\nPor favor escolha uma categoria: ");

				for (Categoria t : Categoria.values()) {
					System.out.println("\t" +t.getValor() + t.getDescricao());
				}
				String categoria = leia.next();

				if (Integer.parseInt(categoria) == 1) {

					do {

						System.out.println("� aposentado?: ");
						System.out.println("1- Sim");
						System.out.println("2- N�o");
						String ehAposentado = leia.next();

						if (Integer.parseInt(ehAposentado) == 1) {
							pessoa.setEhAposentado("Sim");
							pessoa.setCategoria("Empregado");
							verificador = true;
						} else if (Integer.parseInt(ehAposentado) == 2) {
							pessoa.setEhAposentado("N�o");
							pessoa.setCategoria("Empregado");
							pessoa.setQtdFuncionarios(0);
							pessoa.setMesesDesempregado(0);
							verificador = true;
						}

						else {
							System.out.println("\nDigite uma op��o v�lida!");
						}
					} while (verificador == false);
				}

				if (Integer.parseInt(categoria) == 2) {
					verificador = false;
					do {
						System.out.println("Digite a quantidade de funcion�rios da sua empresa: ");
						String qtd = leia.next();

						try {
							if (Integer.parseInt(qtd) > 0) {
								pessoa.setQtdFuncionarios(Integer.parseInt(qtd));
								pessoa.setCategoria("Empregador");
								pessoa.setMesesDesempregado(0);
								pessoa.setEhAposentado("N�o");
								verificador = true;
							} else {
								System.out.println("Quantidade deve ser maior de 0!");
							}
						} catch (NumberFormatException e) {
							System.out.println("\nDigite apenas n�meros!");
						}

					} while (verificador == false);
				}

				if (Integer.parseInt(categoria) == 3) {
					verificador = false;
					do {
						System.out.println("Digite quantos meses est� desempregado: ");
						String qtd = leia.next();

						try {
							if (Integer.parseInt(qtd) > 0) {
								pessoa.setMesesDesempregado(Integer.parseInt(qtd));
								pessoa.setCategoria("DESEMPREGADO");
								pessoa.setEhAposentado("N�o");
								pessoa.setQtdFuncionarios(0);
								verificador = true;
							} else {
								System.out.println("Quantidade deve ser maior de 0!");
							}
						} catch (NumberFormatException e) {
							System.out.println("\nDigite apenas n�meros!");
						}

					} while (verificador == false);
				}

				verificador = false;

				do {
					System.out.println("Digite a uf do seu Estado: ");
					String uf = (leia.next().toUpperCase());

					if (uf.length() == 2) {

						for (EstadosEnum t : EstadosEnum.values()) {
							if (t.getValor().compareTo(uf) == 0) {
								pessoa.setPagamento();
								pessoa.setUf(t.getDescricao());
								verificador = true;
							}
						}
						if (!verificador)
							System.out.println("\nEstado inv�lido! Digite novamente: \n");
							pessoa.setDtRecebimento();
							pessoa.cadastrar();
					} else
						System.out.println("Quantidade de Carateres inv�lida!");
				} while (verificador == false);
				opcao = "0";
				break;
			default:
				System.out.println("Op��o inv�lida! Informe outra op��o:\n");
				opcao = "0";
				break;
					
			
			case "2":
				pessoa.listarTabela();
				
				opcao = "0";
				break;

			case "3":
				
				System.out.println("Digite o id que deseja excluir: ");
				String id = (leia.next());
				
				opcao = "0";
				break;
				
			case "4":

				break;
			}

		}
	}
}

