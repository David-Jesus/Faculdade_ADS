package AppBeneficio.modelagem;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.xml.crypto.Data;

import AppBeneficio.Enumeracoes.Categoria;
import AppBeneficio.Enumeracoes.EstadosEnum;

public class Pessoa {
	private String nomeCompleto;
	private int idade;
	private String categoria;
	private String uf;
	private int qtdFuncionarios;
	private String ehAposentado;
	private int mesesDesempregado;
	private double pagamento;
	private String dt_final_recebimento;
	
	
	public Pessoa(String nome, int idade) {
		this.nomeCompleto = nome;
		this.idade = idade;
	}

	public Pessoa() {
	};

	public void setNome(String nome) {
		this.nomeCompleto = nome;
	}

	public String getNome() {
		return nomeCompleto;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}
	

	public String getNomeCompleto() {
		return nomeCompleto;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public int getQtdFuncionarios() {
		return qtdFuncionarios;
	}

	public void setQtdFuncionarios(int qtdFuncionarios) {
		this.qtdFuncionarios = qtdFuncionarios;
	}

	public String getEhAposentado() {
		return ehAposentado;
	}

	public void setEhAposentado(String ehAposentado) {
		this.ehAposentado = ehAposentado;
	}

	public int getMesesDesempregado() {
		return mesesDesempregado;
	}

	public void setMesesDesempregado(int mesesDesempregado) {
		this.mesesDesempregado = mesesDesempregado;
	}

	public void setPagamento() {
		String categoria = getCategoria();
		
		
		if (getUf().compareTo("Goi�is") == 0) {

			if (categoria.compareTo("EMPREGADO") == 0) {
				this.pagamento = 1000 + ((1000 * 5) / 100);
				if (getEhAposentado().compareTo("Sim") == 0) {
					this.pagamento = pagamento + ((pagamento * 30) / 100);
				}
			
			}
			if (categoria.compareTo("EMPREGADOR") == 0) {

				int valor = 200 * getQtdFuncionarios();
				this.pagamento = valor + ((valor * 5) / 100);
				if (getQtdFuncionarios() <= 10) {
					this.pagamento = pagamento + ((pagamento * 14) / 100);
				}
				if (getQtdFuncionarios() <= 40) {
					this.pagamento = pagamento + ((pagamento * 11) / 100);
				}
				
			}
			if (categoria.compareTo("DESEMPREGADO") == 0) {
				this.pagamento = 2300 + ((2300 * 5) / 100);
			}
		}

		else if (getUf().compareTo("Par�") == 0 || getUf().compareTo("Tocantins") == 0) {

			if (categoria.compareTo("EMPREGADO") == 0) {
				this.pagamento = 1000 + ((1000 * 9) / 100);
				if (getEhAposentado().compareTo("Sim") == 0) {
					this.pagamento = pagamento + ((pagamento * 30) / 100);
				}
			}
			if (categoria.compareTo("EMPREGADOR") == 0) {
				int valor = 200 * getQtdFuncionarios();
				this.pagamento = valor + ((valor * 9) / 100);
				if (getQtdFuncionarios() <= 10) {
					this.pagamento = pagamento + ((pagamento * 14) / 100);
				}
				if (getQtdFuncionarios() <= 40) {
					this.pagamento = pagamento + ((pagamento * 11) / 100);
				}
			
			}
			if (categoria.compareTo("Desempregado") == 0) {
				this.pagamento = 2300 + ((2300 * 9) / 100);
				
			}
		}

		else if (getUf().compareTo("Pernambuco") == 0) {

			if (categoria.compareTo("EMPREGADO") == 0) {
				this.pagamento = 1000 + ((1000 * 14) / 100);
				if (getEhAposentado().compareTo("Sim") == 0 ) {
					this.pagamento = pagamento + ((pagamento * 30) / 100);
				}
				
			}
			if (categoria.compareTo("EMPREGADOR") == 0) {
				int valor = 200 * getQtdFuncionarios();
				this.pagamento = valor + ((valor * 14) / 100);
				if (getQtdFuncionarios() <= 10) {
					this.pagamento = pagamento + ((pagamento * 14) / 100);
				}
				if (getQtdFuncionarios() <= 40) {
					this.pagamento = pagamento + ((pagamento * 11) / 100);
				}
			
			}
			if (categoria.compareTo("Desempregado") == 0) {
				this.pagamento = 2300 + ((2300 * 14) / 100);
			
			}
		}

		else {

			if (categoria.compareTo("EMPREGADO") == 0) {
				this.pagamento = 1000;
				if (getEhAposentado().compareTo("Sim") == 0) {
					this.pagamento = pagamento + ((pagamento * 30) / 100);
				}
				
			}
			if (categoria.compareTo("EMPREGADOR") == 0) {
				this.pagamento = 200 * getQtdFuncionarios();
				if (getQtdFuncionarios() <= 10) {
					this.pagamento = pagamento + ((pagamento * 14) / 100);
				}
				if (getQtdFuncionarios() <= 40) {
					this.pagamento = pagamento + ((pagamento * 11) / 100);
				}
				
			}
			if (categoria.compareTo("Desempregado") == 0) {
				this.pagamento = 2300;
				
			}
		}
		this.pagamento = 2000;
	}

	public void setDtRecebimento() {
		Calendar cal = GregorianCalendar.getInstance();
		int anoAtual = cal.get(Calendar.YEAR);
		int mesAtual = cal.get(Calendar.MONTH) + 1;
		int diaAtual = cal.get(Calendar.DAY_OF_MONTH) ;

		for (int i = 1; i <= 12; i++) {
			mesAtual++;
			if(mesAtual == 12) {
				mesAtual = 0;
				anoAtual++;
			}
		}
		dt_final_recebimento = diaAtual + "/" + mesAtual + "/" + anoAtual;
	}
	public void cadastrar() {
		ConexaoComandos conexaocomandos = new ConexaoComandos();
		conexaocomandos.cadastrar(nomeCompleto, idade, categoria, uf, pagamento, dt_final_recebimento,  qtdFuncionarios, ehAposentado, mesesDesempregado);

	}
	
	public void listarTabela() {
		ConexaoComandos conexaocomandos = new ConexaoComandos();
		conexaocomandos.listar();
	}
	public void deletRegistro(int id) {
		ConexaoComandos conexaocomandos = new ConexaoComandos();
		conexaocomandos.delete(id);
	}
}
